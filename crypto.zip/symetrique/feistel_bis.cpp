#include <iostream>

using namespace std;

int main() {

  bool src[64];
  
  bool texte[64] = { 
    0, 1, 1, 0, 0, 1, 1, 0, 
    0, 1, 0, 0, 1, 1, 1, 1,
    1, 1, 0, 0, 1, 0, 1, 0,
    0, 0, 0, 0, 1, 1, 1, 0,
    0, 1, 1, 0, 0, 1, 1, 0,
    1, 1, 1, 0, 0, 1, 0, 1,
    0, 0, 1, 1, 1, 1, 0, 1,
    0, 1, 0, 1, 0, 1, 1, 0
  };

  bool key[32] = {
    0, 1, 0, 1, 0, 1, 0, 1,
    1, 1, 1, 1, 1, 1, 1, 1,
    0, 0, 0, 1, 1, 0, 0, 1,
    1, 0, 0, 1, 1, 0, 1, 0
  };

  bool gauche[32];
  bool droite[32];

  bool temp;

  bool xorFinal[32];

  int ronde = 10;

  // TEXTE SOURCE
  cout << "S: ";
  for(int i = 0 ; i < 64 ; i++) {
    cout << texte[i];
    src[i] = texte[i];
  }
  cout << endl;
  
  // FEISTEL (CHIFFRE)
  for(int i = 0 ; i < ronde ; i++) {
    for(int j = 0 ; j < 32 ; j++) {
      gauche[j] = texte[j];
      droite[j] = texte[j+32];
    }

    for(int m = 0 ; m < 32 ; m++) {
      temp = key[m] ^ droite[m];
      xorFinal[m] = temp ^ gauche[m]; 
    }

    for(int k = 0 ; k < 32 ; k++) {
      texte[k] = droite[k];
      texte[k+32] = xorFinal[k];
    }
  }
						
  // TEXTE CHIFFRE
  cout << endl << "C: ";
  for(int i = 0 ; i < 64 ; i++) {
    cout << texte[i];
  }
  cout << endl;

  // FEISTEL (DECHIFFRE)
  for(int i = 0 ; i < ronde ; i++) {
    for(int j = 0 ; j < 32 ; j++) {
      gauche[j] = texte[j];
      droite[j] = texte[j+32];
    }
    
    for(int m = 0 ; m < 32 ; m++) {
      temp = key[m] ^ gauche[m];
      xorFinal[m] = temp ^ droite[m];
    }

    for(int k = 0 ; k < 32 ; k++) {
      texte[k] = xorFinal[k];
      texte[k+32] = gauche[k];
    }
  }

  cout << endl << "D: ";
  bool check = true;
  for(int i = 0 ; i < 64 ; i++) {
    check = check && ( texte[i] == src[i] );
  }

  if(check) cout << "TRUE" << endl;
  
  return 0;
}
