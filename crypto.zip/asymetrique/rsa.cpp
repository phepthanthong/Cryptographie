#include <iostream>

using namespace std;

long puissance(long a, long e, long n) {
  long p;

  for(p = 1 ; e > 0 ; e = e/2) {
    if(e % 2 != 0) {
      p = (p * a) % n;
    }
    a = (a * a) % n;
  }
  
  return p;
}

long bezout(long a, long b) {
  long a0 = a;
  long b0 = b;
  
  long p = 1;
  long q = 0;
  long r = 0;
  long s = 1;
  long c = 1;

  while(b != 0) {
    c = a % b;
    long quotient = a/b;
    a = b;
    b = c;
    long nouveau_r = p - quotient * r;
    long nouveau_s = q - quotient * s;
    p = r;
    q = s;
    r = nouveau_r;
    s = nouveau_s;
  }

  if(p < 0) {
    return p + b0;
  }
  else {
    return p;
  }
}

int main() {
  long m = 100;
  long n = 319;
  long e = 11;
  long p = 11;
  long q = 29;

  long chiffre =  puissance(m, e, n);
  long euler = (p-1)*(q-1);
  long d = bezout(e, euler);
  
  cout << d << endl;
  long dechiffre = puissance(chiffre, d, n);
  cout << dechiffre << endl;
  return 0;
}
