#include <iostream>
#include <cstdlib>

using namespace std;

long puissance(long a, long e, long n) {
  long p;

  for(p = 1 ; e > 0 ; e = e/2) {
    if(e % 2 != 0) {
      p = (p * a) % n;
    }
    a = (a * a) % n;
  }
  
  return p;
}

long pgcd(long a, long b) {
  long p = 1, q = 0, r = 0, s = 1;
  long quotient;
  long r_new, s_new;
  long c;

  while( b != 0 ) {
    c = a % b;
    quotient = a / b;
    a = b;
    b = c;
    r_new = p - quotient * r;
    s_new = q - quotient * s;
    p = r;
    q = s;
    r = r_new;
    s = s_new;
  }
  
  return abs(a);
}

bool testFermat(long x) {
  if( puissance(2, x-1, x) != 1 ) return false;
  if( puissance(3, x-1, x) != 1 ) return false;
  if( puissance(5, x-1, x) != 1 ) return false;
  if( puissance(7, x-1, x) != 1 ) return false;
  if( puissance(11, x-1, x) != 1 ) return false;

  return true;
}

long premier() {
  long p = rand() % 100 + 1;
  bool test = false;

  while(!test) {
    if(puissance(2, p-1, p) == 1) {
      test = true;
    }
    else {
      p++;
    }
  }

  return p;
}

long generate_prime() {
  long nb;

  do {
    nb = premier();
  } while( !testFermat(nb) );

  return nb;
}

int main() {
  srand(getpid());
  long p, g;

  p = generate_prime();

  do {
    g = rand() % (p-1) + 1;
  } while( pgcd(g,p) != 1 );

  /***** ALICE *****/
  long a = rand() % p; // garder secret
  long ga = puissance(g,a,p); // envoyer a Bob

  /***** BOB *****/
  long b = rand() % p; // garder srcret
  long gb = puissance(g,b,p); // envoyer a Alice

  /***** CLES IDENTIQUES *****/
  long gba = puissance(gb,a,p); // Alice calcule
  long gab = puissance(ga,b,p); // Bob calcule

  /***** ECRIRE *****/
  cout << "a = " << a << ", ga = " << ga << ", gba = " << gba << endl;
  cout << "b = " << b << ", gb = " << gb << ", gab = " << gab << endl;

  return 0;
}
